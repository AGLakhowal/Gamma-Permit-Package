Gamma Permit Package — Attachment Index
Author: Abhinandan Gill-Lakhowal | Date: 2025-11-16

01-LLC_Gamma-Standard_v1.0.txt
02-ERTuple_Schema_v1.0.json
03-G0_Certification_Scheme.txt
04-Procurement_Clause_Pack_LLC-G0.txt
05-Evaluation_Scoring_Rubric.csv
06-Conformity_Assessment_Checklist.xlsx
07-Vendor_Self-Attestation_Questionnaire.txt
08-Executive_OneSlide_Content.txt
09-IEEE_PAR_Submission_Text.txt
10-BSI_PAS_Outline_and_Rationale.txt
11-NIST_AIRMF_Gamma_Profile_v1.0.txt
12-PEM_Profile_Addendum.txt
/samples/ERTuple_example.json
/samples/PIL_digest_example.json
/samples/Revocation_p95_test_report_sample.txt
